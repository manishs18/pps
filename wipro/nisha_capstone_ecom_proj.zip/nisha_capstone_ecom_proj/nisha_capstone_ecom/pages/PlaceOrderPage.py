import time
from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class PlaceOrderPage(BasePage):
    ADD_TO_CART = (By.XPATH, "(//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart'])[1]")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    PROCEED_TO_CHECKOUT_BUTTON = (By.XPATH, "//a[normalize-space()='Proceed To Checkout']")
    REGISTER_BUTTON = (By.XPATH, "//u[normalize-space()='Register / Login']")
    VERFYING_REGISTER_PAGE =(By.XPATH, "//h2[normalize-space()='New User Signup!']")
    USERNAME = (By.NAME, 'name')
    EMAIL = (By.XPATH, "//input[@data-qa='signup-email']")
    LOGIN = (By.XPATH, "//button[normalize-space()='Signup']")
    AFTER_LOGIN_PAGE_VERIFYING = (By.XPATH, "//b[normalize-space()='Enter Account Information']")
    TITLE_NAME = (By.ID, "id_gender1")
    NAME = (By.XPATH, "//input[@id='name']")
    PASSWORD = (By.XPATH, "//input[@id='password']")
    DATE_DROPDOWN = (By.ID, 'days')
    MONTH_DROPSOWN = (By.ID, 'months')
    YEARS_DROPDOWN = (By.ID, 'years')
    NEWS_LETTER_CHECKBOX = (By.ID, 'newsletter')
    OPTIN_CHECKBOX = (By.ID, 'optin')
    FIRSTNAME = (By.ID, 'first_name')
    LASTNAME = (By.ID, 'last_name')
    COMPANY = (By.ID, 'company')
    ADDRESS1 = (By.ID, 'address1')
    ADDRESS2 = (By.ID, 'address2')
    COUNTRY = (By.ID, 'country')
    STATE = (By.XPATH, "//input[@id='state']")
    CITY = (By.ID, 'city')
    ZIPCODE = (By.ID, 'zipcode')
    MOBILENUMBER = (By.ID, 'mobile_number')
    CREATE_ACCOUNT = (By.XPATH, "//button[normalize-space()='Create Account']")
    ACCOUNT_CREATED = (By.XPATH,"//b[normalize-space()='Account Created!']")
    CONTINUE_BUTTON = (By.XPATH, "//a[normalize-space()='Continue']")
    CART_BUTTON = (By.XPATH, "//a[normalize-space()='Cart']")
    MESSAGE = (By.XPATH, "//textarea[@name='message']")
    PLACE_ORDER = (By.XPATH, "//a[normalize-space()='Place Order']")
    NAME_ON_CARD = (By.XPATH, "//input[@name='name_on_card']")
    CARD_NUMBER = (By.XPATH, "//input[@name='card_number']")
    CVV = (By.XPATH, "//input[@placeholder='ex. 311']")
    MM = (By.XPATH, "//input[@placeholder='MM']")
    YYYY = (By.XPATH, "//input[@placeholder='YYYY']")
    CONFIRM_ORDER_BUTTON = (By.XPATH, "//button[@id='submit']")
    VERIFY_PLACEMENT_SUCCESS = (By.XPATH, "//p[normalize-space()='Congratulations! Your order has been confirmed!']")
    DELETE_ACCOUNT = (By.XPATH, "//a[normalize-space()='Delete Account']")
    VERIFYING_ACCOUNT_DELETED = (By.XPATH, "//b[normalize-space()='Account Deleted!']")
    CONTINUE1 = (By.XPATH, "//a[normalize-space()='Continue']")
    DOWNLOAD_INVOICE_BUTTON = (By.XPATH, "//a[normalize-space()='Download Invoice']")
    DELIVERY_ADDRESS = (By.CSS_SELECTOR, "ul[id='address_delivery'] li[class='address_city address_state_name address_postcode']")
    BILLING_ADDRESS = (By.CSS_SELECTOR, "ul[id='address_invoice'] li[class='address_city address_state_name address_postcode']")




    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_view_and_add_product(self):
        self.scroll_down(0, 700)
        time.sleep(1)
        self.click(*self.ADD_TO_CART)
        time.sleep(1)

    def cart_button(self):
        self.click(*self.VIEW_CART_BUTTON)

    def checkout_button(self):
        self.click(*self.PROCEED_TO_CHECKOUT_BUTTON)

    def register_button(self):
        self.click(*self.REGISTER_BUTTON)

    def enter_name(self, name):
        self.send_keys(*self.USERNAME, name)

    def enter_email(self, email):
        self.send_keys(*self.EMAIL, email)

    def click_signup(self):
        self.click(*self.LOGIN)

    def fill_account_info(self, title, name, password, dob_day, dob_month, dob_year):
        self.click(*self.TITLE_NAME)
        time.sleep(1)
        self.send_keys(*self.NAME, name)
        time.sleep(1)
        self.send_keys(*self.PASSWORD, password)
        time.sleep(1)
        self.select_dropdown(*self.DATE_DROPDOWN, dob_day)
        time.sleep(1)
        self.select_dropdown(*self.MONTH_DROPSOWN, dob_month)
        time.sleep(1)
        self.select_dropdown(*self.YEARS_DROPDOWN, dob_year)

    def select_newsletter_and_offers(self):
        self.click(*self.NEWS_LETTER_CHECKBOX)
        time.sleep(1)
        self.click(*self.OPTIN_CHECKBOX)

    def fill_address(self, first_name, last_name, company, address1, address2, country, state, city, zipcode, mobile_number):
        self.send_keys(*self.FIRSTNAME, first_name)
        time.sleep(1)
        self.send_keys(*self.LASTNAME, last_name)
        time.sleep(1)
        self.send_keys(*self.COMPANY, company)
        time.sleep(1)
        self.send_keys(*self.ADDRESS1, address1)
        time.sleep(1)
        self.send_keys(*self.ADDRESS2, address2)
        time.sleep(1)
        self.select_dropdown(*self.COUNTRY, country)
        time.sleep(1)
        self.send_keys(*self.STATE, state)
        time.sleep(1)
        self.send_keys(*self.CITY, city)
        time.sleep(1)
        self.send_keys(*self.ZIPCODE, zipcode)
        self.send_keys(*self.MOBILENUMBER, mobile_number)
        time.sleep(1)


    def create_account(self):
        self.click(*self.CREATE_ACCOUNT)

    def verify_account_creation(self):
        assert self.is_element_visible(*self.ACCOUNT_CREATED), "ACCOUNT CREATED! message not visible"
        print("ACCOUNT CREATED! message verified.")

    def continue_button(self):
        self.click(*self.CONTINUE_BUTTON)

    def cart_b(self):
        self.click(*self.CART_BUTTON)

    def enter_message(self, data):
        self.send_keys(*self.MESSAGE, data)

    def click_place_order(self):
        self.click(*self.PLACE_ORDER)

    def payment_details(self,nameoncard,number,cvc, expiry, year):
        self.send_keys(*self.NAME_ON_CARD, nameoncard)
        time.sleep(1)
        self.send_keys(*self.CARD_NUMBER, number)
        time.sleep(1)
        self.send_keys(*self.CVV,cvc)
        time.sleep(1)
        self.send_keys(*self.MM,expiry)
        time.sleep(1)
        self.send_keys(*self.YYYY, year)

    def confirm_button(self):
        self.click(*self.CONFIRM_ORDER_BUTTON)

    def verify_success_message(self):
        assert self.is_element_visible(*self.VERIFY_PLACEMENT_SUCCESS), "'Congratulations! Your order has been confirmed!' message not visible"
        print("'Congratulations! Your order has been confirmed!' message verified.")

    def download_invoice(self):
        self.click(*self.DOWNLOAD_INVOICE_BUTTON)

    def delete_account(self):
        self.click(*self.DELETE_ACCOUNT)

    def verify_account_deleted(self):
        assert self.is_element_visible(*self.VERIFYING_ACCOUNT_DELETED), "ACCOUNT DELETED! message not visible"
        print("ACCOUNT DELETED! message verified.")

    def continue_b(self):
        self.click(*self.CONTINUE1)

    def get_billing_address(self):
        billing_address = self.wait_for_element(*self.BILLING_ADDRESS).text.strip()
        print(f"Billing Address: {billing_address}")
        return billing_address

    def get_delivery_address(self):
        delivery_address = self.wait_for_element(*self.DELIVERY_ADDRESS).text.strip()
        print(f"Delivery Address: {delivery_address}")
        return delivery_address







