from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage
import time

class ScrollPageWithoutArrow(BasePage):
    SUBSCRIPTION_SECTION = (By.XPATH, "//div[@class='footer-widget']//div[@class='row']")
    HOME_PAGE_TEXT = (By.XPATH, "//div[@class='item active']//h2[contains(text(),'Full-Fledged practice website for Automation Engin')]")
    HOME_PAGE_HEADER = (By.XPATH, "//img[@alt='Website for automation practice']")

    def verify_home_page_visible(self):
        assert self.is_element_visible(*self.HOME_PAGE_HEADER), "Home page is not visible!"
        print("Home page is visible!")

    def scroll_to_bottom(self):
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    def verify_subscription_visible(self):
        assert self.is_element_visible(*self.SUBSCRIPTION_SECTION), "'SUBSCRIPTION' section is not visible!"
        print("'SUBSCRIPTION' section is visible!")

    def scroll_to_top(self):
        self.driver.execute_script("window.scrollTo(0, 0);")

    def verify_home_page_text_visible(self):
        assert self.is_element_visible(*self.HOME_PAGE_TEXT), "Home page text is not visible!"
        print("'Full-Fledged practice website for Automation Engineers' text is visible!")