import time
from os import times

from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class ProductReviewPage(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    VERIFYING_PRODUCTS_PAGE = (By.XPATH, "//h2[normalize-space()='All Products']")
    VIEW_PRODUCTS_BUTTON = (By.CSS_SELECTOR, "a[href='/product_details/1']")
    VERIFY_REVIEW_SECTION = (By.XPATH, "//a[normalize-space()='Write Your Review']")
    NAME = (By.XPATH, "//input[@id='name']")
    EMAIL = (By.XPATH, "//input[@id='email']")
    REVIEW_AREA = (By.XPATH, "//textarea[@id='review']")
    SUBMIT_BUTTON = (By.XPATH, "//button[@id='button-review']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_products(self):
        self.click(*self.PRODUCTS_BUTTON)

    def verify_products_page(self):
        assert self.is_element_visible(*self.VERIFYING_PRODUCTS_PAGE), "'All Products' word is not visible"
        print("'Products Page' is verified.")

    def click_view_products(self):
        self.click(*self.VIEW_PRODUCTS_BUTTON)

    def verify_review_section(self):
        assert self.is_element_visible(*self.VERIFY_REVIEW_SECTION), "Review section is not visible"
        print("Review Section is visible")

    def review_section(self, name, email, review):
        self.send_keys(*self.NAME, name)
        time.sleep(1)
        self.send_keys(*self.EMAIL, email)
        time.sleep(1)
        self.send_keys(*self.REVIEW_AREA, review)
        time.sleep(1)

    def submit_button(self):
        self.click(*self.SUBMIT_BUTTON)



