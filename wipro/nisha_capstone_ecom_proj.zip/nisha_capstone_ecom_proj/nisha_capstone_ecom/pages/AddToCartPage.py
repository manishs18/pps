from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class AddToCartPage(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    ADD_TO_CART1 = (By.XPATH, "(//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart'])[1]")
    CONTINUE_SHOPPING_BUTTON = (By.XPATH, "//button[normalize-space()='Continue Shopping']")
    ADD_TO_CART2 = (By.XPATH, "(//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart'])[3]")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    PRICE1_VERIFYING = (By.XPATH, "//p[@class='cart_total_price'][normalize-space()='Rs. 500']")
    PRICE2_VERIFYING = (By.XPATH, "//p[@class='cart_total_price'][normalize-space()='Rs. 400']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_products(self):
        self.click(*self.PRODUCTS_BUTTON)

    def add_product1(self):
        self.click(*self.ADD_TO_CART1)

    def click_continue(self):
        self.click(*self.CONTINUE_SHOPPING_BUTTON)

    def add_product_2(self):
        self.click(*self.ADD_TO_CART2)

    def view_cart(self):
        self.click(*self.VIEW_CART_BUTTON)

    def verify_cart(self):
        assert self.is_element_visible(*self.PRICE1_VERIFYING), "Product1 is not in cart"
        print("Product1 is verified.")
        assert self.is_element_visible(*self.PRICE2_VERIFYING), "Product2 is not in cart"
        print("Product2 is verified.")









