from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage
import time

class LoginBeforeCheckout(BasePage):
    LOGIN_TO_ACCOUNT = (By.XPATH, "//a[normalize-space()='Signup / Login']")
    VERFYING_LOGIN_PAGE = (By.XPATH, "//h2[normalize-space()='Login to your account']")
    EMAIL_INPUT = (By.XPATH, "//input[@data-qa='login-email']")
    PASSWORD_INPUT = (By.NAME, "password")
    LOGIN_BUTTON = (By.XPATH, "//button[normalize-space()='Login']")
    VERIFY_LOGGED_IN = (By.XPATH, "//b[normalize-space()='Kishor Patil']")
    ADD_TO_CART = (By.XPATH, "(//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart'])[1]")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    PROCEED_TO_CHECKOUT_BUTTON = (By.XPATH, "//a[normalize-space()='Proceed To Checkout']")
    MESSAGE = (By.XPATH, "//textarea[@name='message']")
    PLACE_ORDER = (By.XPATH, "//a[normalize-space()='Place Order']")
    NAME_ON_CARD = (By.XPATH, "//input[@name='name_on_card']")
    CARD_NUMBER = (By.XPATH, "//input[@name='card_number']")
    CVV = (By.XPATH, "//input[@placeholder='ex. 311']")
    MM = (By.XPATH, "//input[@placeholder='MM']")
    YYYY = (By.XPATH, "//input[@placeholder='YYYY']")
    CONFIRM_ORDER_BUTTON = (By.XPATH, "//button[@id='submit']")
    VERIFY_PLACEMENT_SUCCESS = (By.XPATH, "//p[normalize-space()='Congratulations! Your order has been confirmed!']")


    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def verify_login_page(self):
        assert self.is_element_visible(*self.LOGIN_TO_ACCOUNT), "'Login to your account' not visible"

    def enter_credentials(self, email, password):
        self.send_keys(*self.EMAIL_INPUT, email)
        self.send_keys(*self.PASSWORD_INPUT, password)

    def click_login(self):
        self.click(*self.LOGIN_BUTTON)


    def verify_user_logged_in(self, username):
        user_text = self.wait_for_element(*self.VERIFY_LOGGED_IN).text
        assert username in user_text, f"Expected 'Logged in as {username}', but got '{user_text}'"
        print(f"Logged in as {username} verified successfully.")

    def add_to_cart(self):
        self.click(*self.ADD_TO_CART)

    def cart_b(self):
        self.click(*self.VIEW_CART_BUTTON)

    def checkout_button(self):
        self.click(*self.PROCEED_TO_CHECKOUT_BUTTON)

    def enter_message(self, data):
        self.send_keys(*self.MESSAGE, data)

    def click_place_order(self):
        self.click(*self.PLACE_ORDER)

    def payment_details(self,nameoncard,number,cvc, expiry, year):
        self.send_keys(*self.NAME_ON_CARD, nameoncard)
        time.sleep(1)
        self.send_keys(*self.CARD_NUMBER, number)
        time.sleep(1)
        self.send_keys(*self.CVV,cvc)
        time.sleep(1)
        self.send_keys(*self.MM,expiry)
        time.sleep(1)
        self.send_keys(*self.YYYY, year)

    def confirm_button(self):
        self.click(*self.CONFIRM_ORDER_BUTTON)

    def verify_success_message(self):
        assert self.is_element_visible(*self.VERIFY_PLACEMENT_SUCCESS), "'Congratulations! Your order has been confirmed!' message not visible"
        print("'Congratulations! Your order has been confirmed!' message verified.")