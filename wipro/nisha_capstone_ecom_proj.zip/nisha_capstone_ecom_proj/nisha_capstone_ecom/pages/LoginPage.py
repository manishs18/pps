from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class LoginPage(BasePage):
    LOGIN_TO_ACCOUNT = (By.XPATH, "//a[normalize-space()='Signup / Login']")
    VERFYING_LOGIN_PAGE = (By.XPATH, "//h2[normalize-space()='Login to your account']")
    EMAIL_INPUT = (By.XPATH, "//input[@data-qa='login-email']")
    PASSWORD_INPUT = (By.NAME, "password")
    LOGIN_BUTTON = (By.XPATH, "//button[normalize-space()='Login']")
    ERROR_MESSAGE = (By.XPATH, "//p[normalize-space()='Your email or password is incorrect!']")
    LOGOUT = (By.XPATH, "//a[normalize-space()='Logout']")
    VERIFY_LOGGED_IN = (By.XPATH, "//b[normalize-space()='Kishor Patil']")

    # Methods
    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def verify_login_page(self):
        assert self.is_element_visible(*self.LOGIN_TO_ACCOUNT), "'Login to your account' not visible"

    def enter_credentials(self, email, password):
        self.send_keys(*self.EMAIL_INPUT, email)
        self.send_keys(*self.PASSWORD_INPUT, password)

    def click_login(self):
        self.click(*self.LOGIN_BUTTON)

    def verify_error_message(self):
        assert self.is_element_visible(*self.ERROR_MESSAGE), "Error message for invalid login not visible"
        print("Error message 'Your email or password is incorrect!' verified successfully.")

    def verify_user_logged_in(self, username):
        user_text = self.wait_for_element(*self.VERIFY_LOGGED_IN).text
        assert username in user_text, f"Expected 'Logged in as {username}', but got '{user_text}'"
        print(f"Logged in as {username} verified successfully.")

    def logout(self):
        self.click(*self.LOGOUT)
        print("Logout clicked successfully.")

    def verify_logout(self):
        assert self.is_element_visible(*self.VERFYING_LOGIN_PAGE), "'Login to your account' not visible after logout"
        print("User logged out and redirected to login page.")