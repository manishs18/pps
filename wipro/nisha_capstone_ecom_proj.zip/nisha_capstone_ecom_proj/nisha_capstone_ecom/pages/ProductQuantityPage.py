import time
from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class ProductQTY(BasePage):
    VIEW_PRODUCTS = (By.CSS_SELECTOR, "a[href='/product_details/1']")
    QUANTITY_INPUT = (By.XPATH, "//input[@id='quantity']")
    ADD_TO_CART_BUTTON = (By.XPATH, "//button[normalize-space()='Add to cart']")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    VERIFY_QTY_OFF_PRODUCT_IN_CART = (By.XPATH, "//button[normalize-space()='4']")


    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_view_product(self):
        self.scroll_down(0, 700)
        time.sleep(2)
        self.click(*self.VIEW_PRODUCTS)
        time.sleep(1)


    def set_quantity(self, quantity):
        element = self.wait_for_element(*self.QUANTITY_INPUT)
        element.clear()
        element.send_keys(str(quantity))

    def add_to_cart(self):
        self.click(*self.ADD_TO_CART_BUTTON)

    def view_cart(self):
        self.click(*self.VIEW_CART_BUTTON)

    def verify_quantity_in_cart(self, expected_quantity):
        cart_quantity = self.wait_for_element(*self.VERIFY_QTY_OFF_PRODUCT_IN_CART).text
        assert cart_quantity == str(
            expected_quantity), f"Expected quantity '{expected_quantity}', but got '{cart_quantity}'."
        print(f"Product is displayed in cart with exact quantity: {expected_quantity}.")

