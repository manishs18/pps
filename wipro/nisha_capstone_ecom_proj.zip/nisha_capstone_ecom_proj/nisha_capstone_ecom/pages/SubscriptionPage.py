#subscription_word xpath : //h2[normalize-space()='Subscription']
#

from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class SubscriptionPage(BasePage):
    SUBSCRIPTION_VERIFYING = (By.XPATH, "//h2[normalize-space()='Subscription']")
    EMAIL_INPUT = (By.XPATH, "//input[@id='susbscribe_email']")
    ARROW_BUTTON =(By.XPATH, "//i[@class='fa fa-arrow-circle-o-right']")
    CART_BUTTON = (By.CSS_SELECTOR, "body > header:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > ul:nth-child(1) > li:nth-child(3) > a:nth-child(1)")



    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_cart(self):
        self.click(*self.CART_BUTTON)


    def verify_subscription_text(self):
        assert self.is_element_visible(*self.SUBSCRIPTION_VERIFYING), "Subscription text is not visible"
        print("Subscription text is verified successfully.")


    def enter_email_and_submit(self, email):
        self.send_keys(*self.EMAIL_INPUT, email)
        self.click(*self.ARROW_BUTTON)
        print(f"Email '{email}' entered and arrow button clicked.")



