from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage
import time

class VerifyCartAfterLogin(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    VERIFYING_PRODUCTS_PAGE = (By.XPATH, "//h2[normalize-space()='All Products']")
    SEARCH_BUTTON = (By.XPATH, "//input[@id='search_product']")
    CLICK_SEARCH = (By.XPATH, "//button[@id='submit_search']")
    SEARCHED_PRODUCT_VERIFYING = (By.XPATH, "//h2[normalize-space()='Searched Products']")
    ADD_TO_CART = (By.XPATH, "(//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart'])[1]")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    SIGNUP_BUTTON = (By.XPATH, "//a[normalize-space()='Signup / Login']")
    VERFIFY_LOGIN_PAGE = (By.XPATH, "//h2[normalize-space()='Login to your account']")
    EMAIL_INPUT = (By.XPATH, "//input[@data-qa='login-email']")
    PASSWORD_INPUT = (By.NAME, "password")
    LOGIN_BUTTON = (By.XPATH, "//button[normalize-space()='Login']")
    CART_BUTTON = (By.XPATH, "//a[normalize-space()='Cart']")
    VERIFYING_PRODUCT_IN_CART = (By.XPATH, "//a[normalize-space()='Blue Top']")
    REMOVE_PRODUCTS = (By.XPATH, "//i[@class='fa fa-times']")
    VERIFY_CART_IS_EMPTY = (By.XPATH, "//b[normalize-space()='Cart is empty!']")


    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_products(self):
        self.click(*self.PRODUCTS_BUTTON)

    def verify_products_page(self):
        assert self.is_element_visible(*self.VERIFYING_PRODUCTS_PAGE), "'All Products' word is not visible"
        print("'Products Page' is verified.")

    def click_search_products(self,search):
        self.scroll_down(0, 600)
        self.send_keys(*self.SEARCH_BUTTON, search)

    def click_search_button(self):
        self.click(*self.CLICK_SEARCH)

    def verify_searched_products(self):
        assert self.is_element_visible(*self.SEARCHED_PRODUCT_VERIFYING), "'Searched Products' is not visible"
        print("'Searched Products' is verified.")
        time.sleep(1)

    def add_to_cart(self):
        self.scroll_down(0, 1000)
        self.click(*self.ADD_TO_CART)

    def click_on_cart(self):
        self.click(*self.VIEW_CART_BUTTON)

    def click_on_signup(self):
        self.click(*self.SIGNUP_BUTTON)

    def enter_credentials(self, email, password):
        self.send_keys(*self.EMAIL_INPUT, email)
        self.send_keys(*self.PASSWORD_INPUT, password)

    def click_login(self):
        self.click(*self.LOGIN_BUTTON)

    def click_cart(self):
        self.click(*self.CART_BUTTON)

    def verify_product_in_cart(self):
        assert self.is_element_visible(*self.VERIFYING_PRODUCT_IN_CART), "Products not in cart"
        print("Products are in cart.")

    def remove_product(self):
        self.click(*self.REMOVE_PRODUCTS)

    def verify_cart_empty(self):
        assert self.is_element_visible(*self.VERIFY_CART_IS_EMPTY), "Cart is not empty"
        print("Cart is empty is visible.")










