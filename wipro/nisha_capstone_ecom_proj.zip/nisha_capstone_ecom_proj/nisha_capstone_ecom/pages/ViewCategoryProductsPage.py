from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class ViewCategoryProducts(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    WOMEN_CATEGORY = (By.XPATH, "//a[normalize-space()='Women']")
    CLICK_DRESS = (By.CSS_SELECTOR, "a[href='/category_products/1']")
    VERIFY_WOMEN_SUBCATEGORY = (By.XPATH, "//h2[normalize-space()='Women - Dress Products']")
    CLICK_MEN_CATEGORY = (By.XPATH, "//a[normalize-space()='Men']")
    CLICK_MEN_SUB_CATEGORY = (By.XPATH, "//a[normalize-space()='Tshirts']")
    VERIFY_MEN_SUB_CATEGORY = (By.XPATH, "//h2[normalize-space()='Men - Tshirts Products']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_products(self):
        self.click(*self.PRODUCTS_BUTTON)

    def click_women_cat(self):
        self.scroll_down(0, 500)
        self.click(*self.WOMEN_CATEGORY)

    def click_women_subcat(self):
        self.click(*self.CLICK_DRESS)

    def verify_women_subcat(self):
        assert self.is_element_visible(*self.VERIFY_WOMEN_SUBCATEGORY), "'WOMEN-SUBCATEGORY' is not visible"
        print("'WOMEN-SUBCATEGORY' is verified.")

    def click_men_category(self):
        self.click(*self.CLICK_MEN_CATEGORY)

    def click_men_subcategory(self):
        self.click(*self.CLICK_MEN_SUB_CATEGORY)

    def verify_men_subcategory(self):
        self.click(*self.VERIFY_MEN_SUB_CATEGORY)


