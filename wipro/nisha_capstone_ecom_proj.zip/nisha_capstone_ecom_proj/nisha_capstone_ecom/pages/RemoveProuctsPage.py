import time
from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class RemoveProductsPage(BasePage):
    ADD_TO_CART = (By.XPATH, "(//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart'])[1]")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    PRICE1_VERIFYING = (By.XPATH, "//p[@class='cart_total_price'][normalize-space()='Rs. 500']")
    DELETE_PRODUCT_BUTTON = (By.XPATH, "//a[@class='cart_quantity_delete']")
    VERIFY_PRODUCT_DELETED = (By.XPATH, "//b[normalize-space()='Cart is empty!']")


    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_view_and_add_product(self):
        self.scroll_down(0, 700)
        time.sleep(1)
        self.click(*self.ADD_TO_CART)
        time.sleep(1)

    def cart_button(self):
        self.click(*self.VIEW_CART_BUTTON)

    def verify_cart(self):
        assert self.is_element_visible(*self.PRICE1_VERIFYING), "Cart is displayed"
        print("Cart is not visible.")

    def click_x(self):
        self.click(*self.DELETE_PRODUCT_BUTTON)

    def verify_product_removed(self):
        assert self.is_element_visible(*self.VERIFY_PRODUCT_DELETED), "'Cart is empty!' is displayed, hence product is removed"
        print("PRODUCT NOT DELETED.")

