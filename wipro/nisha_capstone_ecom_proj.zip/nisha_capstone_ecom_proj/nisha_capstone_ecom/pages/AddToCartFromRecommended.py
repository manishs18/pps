import time
from os import times

from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class AddToCartFromRecommended(BasePage):
    VERIFY_RECOMMENDED_ITEMS = (By.XPATH, "//h2[normalize-space()='recommended items']")
    ADD_TO_CART = (By.XPATH, "(//a[@class='btn btn-default add-to-cart'][normalize-space()='Add to cart'])[72]")
    VIEW_CART_BUTTON = (By.XPATH, "//u[normalize-space()='View Cart']")
    VERIFY_CART = (By.XPATH, "//a[normalize-space()='Stylish Dress']")


    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def scroll_to_bottom(self):
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    def verify_recommended_items(self):
        assert self.is_element_visible(*self.VERIFY_RECOMMENDED_ITEMS), "'RECOMMENDED ITEMS' section is not visible!"
        print("'RECOMMENDED ITEMS' section is visible!")

    def add_to_cart(self):
        self.click(*self.ADD_TO_CART)

    def view_cart(self):
        self.click(*self.VIEW_CART_BUTTON)

    def verify_product_in_cart(self):
        assert self.is_element_visible(*self.VERIFY_CART), "'RECOMMENDED ITEMS' section is not visible!"
        print("'RECOMMENDED ITEMS' section is visible!")

