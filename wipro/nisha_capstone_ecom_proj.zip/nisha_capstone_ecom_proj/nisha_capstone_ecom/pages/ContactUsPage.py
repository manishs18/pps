from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class ContactUsPage(BasePage):
    CONTACTUS_BUTTON = (By.XPATH, "//a[normalize-space()='Contact us']")
    VERIFYING_CONTACT_PAGE = (By.XPATH, "//h2[normalize-space()='Get In Touch']")
    NAME = (By.NAME, 'name')
    EMAIL = (By.NAME, "email")
    SUBJECT = (By.NAME, 'subject')
    MESSAGE = (By.ID, "message")
    CHOOSE_FILE_BUTTON = (By.XPATH, "//input[@name='upload_file']")
    SUBMIT_BUTTON = (By.XPATH, "//input[@name='submit']")
    VERIFYING_SUCCESS = (By.XPATH, "//div[@class='status alert alert-success']")
    HOME_BUTTON = (By.XPATH, "//span[normalize-space()='Home']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_contactus(self):
        self.click(*self.CONTACTUS_BUTTON)

    def verify_contactus_page(self):
        assert self.is_element_visible(*self.VERIFYING_CONTACT_PAGE), "'GET IN TOUCH' is not visible"
        print("'GET IN TOUCH' is verified.")

    def fill_contact_form(self, name, email, subject, message):
        self.send_keys(*self.NAME, name)
        self.send_keys(*self.EMAIL, email)
        self.send_keys(*self.SUBJECT, subject)
        self.send_keys(*self.MESSAGE, message)
        print("Contact form filled successfully.")

    def upload_file(self, file_path):
        self.send_keys(*self.CHOOSE_FILE_BUTTON, file_path)

    def submit_form(self):
        self.click(*self.SUBMIT_BUTTON)

    def verify_success_message(self):
        assert self.is_element_visible(*self.VERIFYING_SUCCESS), "Success message not visible"
        print("Success message 'Your details have been submitted successfully.' verified.")

    def click_home_button(self):
        self.click(*self.HOME_BUTTON)
        print("Home button clicked.")

