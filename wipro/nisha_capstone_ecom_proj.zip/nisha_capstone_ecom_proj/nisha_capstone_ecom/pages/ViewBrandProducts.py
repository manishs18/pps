from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage
import time

class ViewBrandProducts(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    BRAND = (By.CSS_SELECTOR, "a[href='/brand_products/Polo']")
    BRAND_PAGE_VERIFY = (By.XPATH, "//h2[normalize-space()='Brand - Polo Products']")
    CLICK_ANOTHER_BRAND = (By.CSS_SELECTOR, "a[href='/brand_products/H&M']")
    VERIFY_SECOND_BRAND = (By.XPATH, "//h2[normalize-space()='Brand - H&M Products']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_products(self):
        self.click(*self.PRODUCTS_BUTTON)

    def click_brand(self):
        self.scroll_down(0, 1600)
        self.click(*self.BRAND)

    def verify_brand(self):
        assert self.is_element_visible(*self.BRAND_PAGE_VERIFY), "'BRAND_PAGE' is not visible"
        print("'BRAND_PAGE' is verified.")

    def click_another_brand(self):
        self.click(*self.CLICK_ANOTHER_BRAND)

    def verify_another_brand(self):
        assert self.is_element_visible(*self.VERIFY_SECOND_BRAND), "'OTHER BRAND PAGE' is not visible"
        print("'OTHER BRAND PAGE' is verified.")


