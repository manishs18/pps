from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage
import time

class RegisterPage(BasePage):
    SIGNUPBUTTON = (By.XPATH, "//a[normalize-space()='Signup / Login']")
    VERFYING_REGISTER_PAGE =(By.XPATH, "//h2[normalize-space()='New User Signup!']")
    USERNAME = (By.NAME, 'name')
    EMAIL = (By.XPATH, "//input[@data-qa='signup-email']")
    LOGIN = (By.XPATH, "//button[normalize-space()='Signup']")
    AFTER_LOGIN_PAGE_VERIFYING = (By.XPATH, "//b[normalize-space()='Enter Account Information']")
    TITLE_NAME = (By.ID, "id_gender1")
    NAME = (By.XPATH, "//input[@id='name']")
    PASSWORD = (By.XPATH, "//input[@id='password']")
    DATE_DROPDOWN = (By.ID, 'days')
    MONTH_DROPSOWN = (By.ID, 'months')
    YEARS_DROPDOWN = (By.ID, 'years')
    NEWS_LETTER_CHECKBOX = (By.ID, 'newsletter')
    OPTIN_CHECKBOX = (By.ID, 'optin')
    FIRSTNAME = (By.ID, 'first_name')
    LASTNAME = (By.ID, 'last_name')
    COMPANY = (By.ID, 'company')
    ADDRESS1 = (By.ID, 'address1')
    ADDRESS2 = (By.ID, 'address2')
    COUNTRY = (By.ID, 'country')
    STATE = (By.XPATH, "//input[@id='state']")
    CITY = (By.ID, 'city')
    ZIPCODE = (By.ID, 'zipcode')
    MOBILENUMBER = (By.ID, 'mobile_number')
    CREATE_ACCOUNT = (By.XPATH, "//button[normalize-space()='Create Account']")
    ACCOUNT_CREATED = (By.XPATH,"//b[normalize-space()='Account Created!']")
    CONTINUE_BUTTON = (By.XPATH, "//a[normalize-space()='Continue']")
    VERIFY_USER_LOGIN = (By.CSS_SELECTOR, "li:nth-child(10) a:nth-child(1)")
    DELETE_ACCOUNT = (By.XPATH, "//a[normalize-space()='Delete Account']")
    VERIFYING_ACCOUNT_DELETED = (By.XPATH, "//b[normalize-space()='Account Deleted!']")
    CONTINUE1 = (By.XPATH, "//a[normalize-space()='Continue']")
    ERROR_MESSAGE = (By.XPATH, "//h3[@data-test='error']")
    ERROR_MESSAGE1 = (By.XPATH, "//p[normalize-space()='Email Address already exist!']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def sigunp_button(self):
        self.click(*self.SIGNUPBUTTON)

    def enter_name(self, name):
        self.send_keys(*self.USERNAME, name)

    def enter_email(self, email):
        self.send_keys(*self.EMAIL, email)

    def click_signup(self):
        self.click(*self.LOGIN)

    def fill_account_info(self, title, name, password, dob_day, dob_month, dob_year):
        self.click(*self.TITLE_NAME)
        time.sleep(1)
        self.send_keys(*self.NAME, name)
        time.sleep(1)
        self.send_keys(*self.PASSWORD, password)
        time.sleep(1)
        self.select_dropdown(*self.DATE_DROPDOWN, dob_day)
        time.sleep(1)
        self.select_dropdown(*self.MONTH_DROPSOWN, dob_month)
        time.sleep(1)
        self.select_dropdown(*self.YEARS_DROPDOWN, dob_year)

    def select_newsletter_and_offers(self):
        self.click(*self.NEWS_LETTER_CHECKBOX)
        time.sleep(1)
        self.click(*self.OPTIN_CHECKBOX)

    def fill_address(self, first_name, last_name, company, address1, address2, country, state, city, zipcode, mobile_number):
        self.send_keys(*self.FIRSTNAME, first_name)
        time.sleep(1)
        self.send_keys(*self.LASTNAME, last_name)
        time.sleep(1)
        self.send_keys(*self.COMPANY, company)
        time.sleep(1)
        self.send_keys(*self.ADDRESS1, address1)
        time.sleep(1)
        self.send_keys(*self.ADDRESS2, address2)
        time.sleep(1)
        self.select_dropdown(*self.COUNTRY, country)
        time.sleep(1)
        self.send_keys(*self.STATE, state)
        time.sleep(1)
        self.send_keys(*self.CITY, city)
        time.sleep(1)
        self.send_keys(*self.ZIPCODE, zipcode)
        self.send_keys(*self.MOBILENUMBER, mobile_number)
        time.sleep(1)


    def create_account(self):
        self.click(*self.CREATE_ACCOUNT)

    def verify_account_creation(self):
        assert self.is_element_visible(*self.ACCOUNT_CREATED), "ACCOUNT CREATED! message not visible"
        print("ACCOUNT CREATED! message verified.")

    def continue_button(self):
        self.click(*self.CONTINUE_BUTTON)


    def delete_account(self):
        self.click(*self.DELETE_ACCOUNT)

    def verify_account_deleted(self):
        assert self.is_element_visible(*self.VERIFYING_ACCOUNT_DELETED), "ACCOUNT DELETED! message not visible"
        print("ACCOUNT DELETED! message verified.")

    def verify_email_exists_error(self):
        assert self.is_element_visible(*self.ERROR_MESSAGE1), "Error message 'Email Address already exist!' not visible"
        print("Error message 'Email Address already exist!' verified.")

