from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class BasePage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)

    def wait_for_element(self, by, locator):
        return self.wait.until(EC.visibility_of_element_located((by, locator)))

    def click(self, by, locator):
        element = self.wait_for_element(by, locator)
        element.click()

    def send_keys(self, by, locator, text):
        element = self.wait_for_element(by, locator)
        element.clear()
        element.send_keys(text)

    def select_dropdown(self, by, locator, value):
        element = self.wait_for_element(by, locator)
        select = Select(element)
        select.select_by_visible_text(value)

    def is_element_visible(self, by, locator):
        try:
            element = self.wait_for_element(by, locator)
            return element.is_displayed()
        except Exception:
            return False

    def accept_alert(self):
        self.wait.until(EC.alert_is_present()).accept()
        print("Alert accepted.")

    def dismiss_alert(self):
        self.wait.until(EC.alert_is_present()).dismiss()
        print("Alert dismissed.")

    def get_alert_text(self):
        alert = self.wait.until(EC.alert_is_present())
        print(f"Alert text: {alert.text}")
        return alert.text

    def scroll_to_element(self, by, locator):
        element = self.wait_for_element(by, locator)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        print(f"Scrolled to element: {locator}")

    def scroll_down(self, x, y):
        self.driver.execute_script(f"window.scrollBy({x}, {y});")
        print(f"Scrolled down by x: {x}, y: {y}")

