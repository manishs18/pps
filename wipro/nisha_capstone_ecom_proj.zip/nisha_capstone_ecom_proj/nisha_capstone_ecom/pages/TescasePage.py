from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class TestcasePage(BasePage):
    TESTCASE_BUTTON = (By.XPATH, "//a[contains(text(),'Test Cases')]")
    VERIFYING_TEST_CASE_PAGE = (By.XPATH, "//b[normalize-space()='Test Cases']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_testcase(self):
        self.click(*self.TESTCASE_BUTTON)

    def verify_testcase_page(self):
        assert self.is_element_visible(*self.VERIFYING_TEST_CASE_PAGE), "'Test Cases' word is not visible"
        print("'Test Cases' is verified.")