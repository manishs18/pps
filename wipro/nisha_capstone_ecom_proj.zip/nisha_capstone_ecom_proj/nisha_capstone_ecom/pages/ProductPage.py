from selenium.webdriver.common.by import By
from nisha_capstone_ecom.pages.Basepage import BasePage

class ProductPage(BasePage):
    PRODUCTS_BUTTON = (By.XPATH, "//a[@href='/products']")
    VERIFYING_PRODUCTS_PAGE = (By.XPATH, "//h2[normalize-space()='All Products']")
    SEARCH_BUTTON = (By.XPATH, "//input[@id='search_product']")
    CLICK_SEARCH = (By.XPATH, "//button[@id='submit_search']")
    SEARCHED_PRODUCT_VERIFYING = (By.XPATH, "//h2[normalize-space()='Searched Products']")
    VIEW_PRODUCTS_BUTTON = (By.CSS_SELECTOR, "a[href='/product_details/1']")
    PRODUCT_NAME_VERIFYING = (By.XPATH, "//h2[normalize-space()='Blue Top']")
    CATEGORY_VERIFYING = (By.XPATH, "//p[normalize-space()='Category: Women > Tops']")
    PRICE_VERIFYING = (By.XPATH, "//span[normalize-space()='Rs. 500']")
    AVAILABILITY_VERIFYING = (By.XPATH, "//b[normalize-space()='Availability:']")
    CONDITION_VERIFYING = (By.XPATH, "//b[normalize-space()='Condition:']")
    BRAND_VERIFYING = (By.XPATH, "//b[normalize-space()='Brand:']")

    def verify_homepage_title(self):
        assert self.driver.title == "Automation Exercise", f"Expected title 'Automation Exercise', but got '{self.driver.title}'"
        print("Home page title verified successfully.")

    def click_products(self):
        self.click(*self.PRODUCTS_BUTTON)

    def verify_products_page(self):
        assert self.is_element_visible(*self.VERIFYING_PRODUCTS_PAGE), "'All Products' word is not visible"
        print("'Products Page' is verified.")

    def click_view_products(self):
        self.click(*self.VIEW_PRODUCTS_BUTTON)

    def verify_products_name(self):
        assert self.is_element_visible(*self.PRODUCT_NAME_VERIFYING), "'Product Name' is not visible"
        print("'Products Name' is verified.")

    def verify_category(self):
        assert self.is_element_visible(*self.CATEGORY_VERIFYING), "'Category' is not visible"
        print("'Category' is verified.")

    def verify_price(self):
        assert self.is_element_visible(*self.PRICE_VERIFYING), "'Price' is not visible"
        print("'Price' is verified.")

    def verify_availability(self):
        assert self.is_element_visible(*self.AVAILABILITY_VERIFYING), "'Availability' is not visible"
        print("'Availability' is verified.")

    def verify_condition(self):
        assert self.is_element_visible(*self.CONDITION_VERIFYING), "'Condition' is not visible"
        print("'Condition' is verified.")

    def verify_brand(self):
        assert self.is_element_visible(*self.BRAND_VERIFYING), "'Brand' is not visible"
        print("'Brand' is verified.")

    def click_search_products(self,search):
        self.send_keys(*self.SEARCH_BUTTON, search)

    def click_search_button(self):
        self.click(*self.CLICK_SEARCH)

    def verify_searched_products(self):
        assert self.is_element_visible(*self.SEARCHED_PRODUCT_VERIFYING), "'Searched Products' is not visible"
        print("'Searched Products' is verified.")









