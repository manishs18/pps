import pytest
import time
from nisha_capstone_ecom.pages.ProductPage import ProductPage
from selenium import webdriver

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get("http://automationexercise.com")
    yield driver
    driver.close()

def test_product(driver):
    test_productpage = ProductPage(driver)
    test_productpage.verify_homepage_title()
    time.sleep(1)
    test_productpage.click_products()
    time.sleep(2)
    test_productpage.verify_products_page()
    time.sleep(2)
    test_productpage.click_view_products()
    time.sleep(2)
    test_productpage.verify_products_name()
    time.sleep(1)
    test_productpage.verify_category()
    time.sleep(1)
    test_productpage.verify_price()
    time.sleep(1)
    test_productpage.verify_availability()
    time.sleep(1)
    test_productpage.verify_condition()
    time.sleep(1)
