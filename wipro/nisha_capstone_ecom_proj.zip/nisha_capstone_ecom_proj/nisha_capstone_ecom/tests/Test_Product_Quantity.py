import time
import pytest
from nisha_capstone_ecom.pages.ProductQuantityPage import ProductQTY
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_verify_product_quantity_in_cart(driver):
    product_page = ProductQTY(driver)
    time.sleep(2)

    product_page.verify_homepage_title()
    time.sleep(1)

    product_page.click_view_product()
    time.sleep(1)

    product_page.set_quantity(4)
    time.sleep(1)
    product_page.add_to_cart()
    time.sleep(1)

    product_page.view_cart()
    time.sleep(1)
    product_page.verify_quantity_in_cart(4)
    time.sleep(1)

