from time import sleep

import pytest
import time
from nisha_capstone_ecom.pages.VerifyCartAfterLoginPage import VerifyCartAfterLogin
from selenium import webdriver

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get("http://automationexercise.com")
    yield driver
    driver.close()

def test_product(driver):
    test_viewcart = VerifyCartAfterLogin(driver)
    test_viewcart.verify_homepage_title()
    time.sleep(1)
    test_viewcart.click_products()
    time.sleep(1)
    test_viewcart.verify_products_page()
    time.sleep(1)
    test_viewcart.add_to_cart()
    time.sleep(1)
    test_viewcart.click_on_cart()
    time.sleep(1)
    test_viewcart.click_on_signup()
    time.sleep(1)
    test_viewcart.enter_credentials("nisha255@gmail.com","nisha@255")
    time.sleep(1)
    test_viewcart.click_login()
    time.sleep(1)
    test_viewcart.click_cart()
    time.sleep(1)
    test_viewcart.verify_product_in_cart()
    time.sleep(1)
    test_viewcart.remove_product()
    time.sleep(1)
    test_viewcart.verify_cart_empty()
    time.sleep(1)