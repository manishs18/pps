import time
import pytest
from nisha_capstone_ecom.pages.LoginPage import LoginPage
from selenium import webdriver

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_login_user(driver):
    email = "nisha255@gmail.com"
    password = "nish@255"
    username = "nisha255"
    nameoncard = "Master Nisha Deshmukh"
    number = "34731234"
    cvc = "255"
    expiry = "09"
    year = "28"

    login_page = LoginPage(driver)
    time.sleep(2)

    login_page.verify_homepage_title()
    time.sleep(2)

    login_page.click(*login_page.LOGIN_TO_ACCOUNT)
    time.sleep(2)

    login_page.verify_login_page()
    time.sleep(2)

    login_page.enter_credentials(email, password)
    login_page.click_login()
    time.sleep(2)

    login_page.verify_user_logged_in(username)
    time.sleep(2)
