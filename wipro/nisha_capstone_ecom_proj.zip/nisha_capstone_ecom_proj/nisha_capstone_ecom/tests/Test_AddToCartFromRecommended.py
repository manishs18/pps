import pytest
from nisha_capstone_ecom.pages.AddToCartFromRecommended import AddToCartFromRecommended
from selenium import webdriver
import time

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_verify_scroll_functionality(driver):
    addfrom_recommended = AddToCartFromRecommended(driver)
    time.sleep(1)
    addfrom_recommended.verify_homepage_title()
    time.sleep(1)
    addfrom_recommended.scroll_to_bottom()
    time.sleep(1)
    addfrom_recommended.verify_recommended_items()
    time.sleep(1)
    addfrom_recommended.add_to_cart()
    time.sleep(2)
    addfrom_recommended.view_cart()
    time.sleep(2)
    addfrom_recommended.verify_product_in_cart()
    time.sleep(1)
