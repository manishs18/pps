import time
import pytest
from nisha_capstone_ecom.pages.ProductPage import ProductPage
from nisha_capstone_ecom.pages.SubscriptionPage import SubscriptionPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()


def test_verify_subscription(driver):
    subscription_page = SubscriptionPage(driver)

    subscription_page.click_cart()
    time.sleep(1)

    subscription_page.scroll_to_element(*SubscriptionPage.SUBSCRIPTION_VERIFYING)
    time.sleep(1)
    print("Scrolled down to the footer.")


    subscription_page.verify_subscription_text()

    subscription_page.enter_email_and_submit("nisha255@gmail.com")
    time.sleep(2)

    print("'You have been successfully subscribed!' ")