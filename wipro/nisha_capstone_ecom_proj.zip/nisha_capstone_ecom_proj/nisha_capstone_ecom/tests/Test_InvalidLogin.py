import time
import pytest
from nisha_capstone_ecom.pages.LoginPage import LoginPage
from selenium import webdriver

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_login_invalid_user(driver):
    invalid_email = "nishad@gmail.com"
    invalid_password = "nishad123"

    login_page = LoginPage(driver)
    time.sleep(2)

    login_page.verify_homepage_title()
    time.sleep(2)

    login_page.click(*login_page.LOGIN_TO_ACCOUNT)
    time.sleep(2)

    login_page.verify_login_page()
    time.sleep(2)

    login_page.enter_credentials(invalid_email, invalid_password)
    login_page.click_login()
    time.sleep(2)

    login_page.verify_error_message()
    time.sleep(2)