import time

import pytest
from nisha_capstone_ecom.pages.AddToCartPage import AddToCartPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()



def test_add_to_cart(driver):
    test_addtocart = AddToCartPage(driver)
    test_addtocart.verify_homepage_title()
    time.sleep(1)

    test_addtocart.click_products()
    time.sleep(1)
    test_addtocart.add_product1()
    time.sleep(1)
    test_addtocart.click_continue()
    time.sleep(1)
    test_addtocart.add_product_2()
    time.sleep(2)
    test_addtocart.view_cart()
    time.sleep(1)
    test_addtocart.verify_cart()
    time.sleep(1)