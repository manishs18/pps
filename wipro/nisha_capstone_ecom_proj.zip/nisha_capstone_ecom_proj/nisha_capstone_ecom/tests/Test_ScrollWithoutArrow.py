import pytest
from nisha_capstone_ecom.pages.ScrollWithoutArrowPage import ScrollPageWithoutArrow
from selenium import webdriver
import time

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_verify_scroll_functionality(driver):
    scroll_page = ScrollPageWithoutArrow(driver)
    time.sleep(1)
    scroll_page.verify_home_page_visible()
    time.sleep(1)
    scroll_page.scroll_to_bottom()
    time.sleep(1)
    scroll_page.verify_subscription_visible()
    time.sleep(2)
    scroll_page.scroll_to_top()
    time.sleep(2)
    scroll_page.verify_home_page_text_visible()
    time.sleep(1)
    print("Test case passed: Verified scrolling successfully!")