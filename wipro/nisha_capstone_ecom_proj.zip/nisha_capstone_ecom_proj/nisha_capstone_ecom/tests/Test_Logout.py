import time
import pytest
from nisha_capstone_ecom.pages.LoginPage import LoginPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()


def test_logout_user(driver):
    email = "nisha255@gmail.com"
    password = "nisha@255"

    login_page = LoginPage(driver)

    login_page.verify_homepage_title()

    login_page.click(*login_page.LOGIN_TO_ACCOUNT)

    login_page.verify_login_page()

    login_page.enter_credentials(email, password)
    login_page.click_login()
    time.sleep(2)

    login_page.verify_user_logged_in("nisha255")

    login_page.logout()
    time.sleep(2)

    login_page.verify_logout()