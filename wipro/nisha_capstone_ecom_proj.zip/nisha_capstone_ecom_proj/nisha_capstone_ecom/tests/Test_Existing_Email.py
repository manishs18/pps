import time
import pytest
from nisha_capstone_ecom.pages.RegisterPage import RegisterPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()



def test_register_user_with_existing_email(driver):
    name = "nisha25"
    existing_email = "nisha25@gmail.com"

    register_page = RegisterPage(driver)

    register_page.verify_homepage_title()

    register_page.sigunp_button()

    assert "New User Signup!" in driver.page_source
    time.sleep(2)

    register_page.enter_name(name)
    register_page.enter_email(existing_email)

    register_page.click_signup()
    time.sleep(2)

    register_page.verify_email_exists_error()