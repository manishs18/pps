import time

import pytest
from nisha_capstone_ecom.pages.TescasePage import TestcasePage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()



def test_test_cases_page(driver):
    testcase_page = TestcasePage(driver)
    testcase_page.verify_homepage_title()
    time.sleep(1)

    testcase_page.click_testcase()
    time.sleep(2)

    testcase_page.verify_testcase_page()
    time.sleep(2)
