import pytest
from nisha_capstone_ecom.pages.RegisterPage import RegisterPage
from selenium import webdriver
import time

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()


def test_register_user(driver):
    name = "nisha255"
    email = "nisha255@gmail.com"
    title = "Mrs."
    password = "nisha@255"
    dob_day = "22"
    dob_month = "February"
    dob_year = "2000"
    first_name = "Nishaaa"
    last_name = "Deshmukhhh"
    company = "Wipro"
    address1 = "Pune"
    address2 = "Mumbai"
    country = "India"
    state = "Maharashtra"
    city = "Mumbai"
    zipcode = "427485"
    mobile_number = "8598123456"
    nameoncard = "Master Nisha Deshmukh"
    number = "34731234"
    cvc = "255"
    expiry = "09"
    year = "28"
    

    register_page = RegisterPage(driver)
    register_page.verify_homepage_title()
    time.sleep(2)

    register_page.sigunp_button()
    time.sleep(2)

    assert "New User Signup!" in driver.page_source
    time.sleep(2)

    register_page.enter_name(name)
    time.sleep(2)
    register_page.enter_email(email)
    time.sleep(2)
    register_page.click_signup()
    time.sleep(2)

    assert "Enter Account Information" in driver.page_source
    time.sleep(2)

    register_page.fill_account_info(title, name, password, dob_day, dob_month, dob_year)
    time.sleep(2)
    register_page.select_newsletter_and_offers()
    time.sleep(2)

    register_page.fill_address(first_name, last_name, company, address1, address2, country, state, city, zipcode,
                               mobile_number)
    time.sleep(2)

    register_page.create_account()
    time.sleep(2)

    register_page.verify_account_creation()
    time.sleep(2)

    register_page.continue_button()
    time.sleep(2)


    # register_page.delete_account()
    # time.sleep(2)
    # register_page.verify_account_deleted()
    # time.sleep(2)

    # print("Test case passed for user registration and account deletion!")