import pytest
import time
from nisha_capstone_ecom.pages.ViewBrandProducts import ViewBrandProducts
from selenium import webdriver

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get("http://automationexercise.com")
    yield driver
    driver.close()

def test_product(driver):
    test_viewbrands = ViewBrandProducts(driver)
    test_viewbrands.verify_homepage_title()
    time.sleep(1)
    test_viewbrands.click_products()
    time.sleep(1)
    test_viewbrands.click_brand()
    time.sleep(1)
    test_viewbrands.verify_brand()
    time.sleep(1)
    test_viewbrands.click_another_brand()
    time.sleep(1)
    test_viewbrands.verify_another_brand()
    time.sleep(1)