import time
import pytest
from nisha_capstone_ecom.pages.PlaceOrderPage import PlaceOrderPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_place_order(driver):
    name = "nisha255"
    email = "nisha255@gmail.com"
    title = "Mrs."
    password = "nisha@255"
    dob_day = "22"
    dob_month = "February"
    dob_year = "2000"
    first_name = "Nishaaa"
    last_name = "Deshmukhhh"
    company = "Wipro"
    address1 = "Pune"
    address2 = "Mumbai"
    country = "India"
    state = "Maharashtra"
    city = "Mumbai"
    zipcode = "427485"
    mobile_number = "8598123456"
    nameoncard = "Master Nisha Deshmukh"
    number = "34731234"
    cvc = "255"
    expiry = "09"
    year = "28"

    test_placeorder = PlaceOrderPage(driver)
    time.sleep(2)

    test_placeorder.verify_homepage_title()
    time.sleep(1)

    test_placeorder.click_view_and_add_product()
    time.sleep(1)
    test_placeorder.cart_button()
    time.sleep(1)
    test_placeorder.checkout_button()
    time.sleep(1)
    test_placeorder.register_button()

    assert "New User Signup!" in driver.page_source
    time.sleep(2)

    test_placeorder.enter_name(name)
    time.sleep(2)
    test_placeorder.enter_email(email)
    time.sleep(2)
    test_placeorder.click_signup()
    time.sleep(2)

    assert "Enter Account Information" in driver.page_source
    time.sleep(2)

    test_placeorder.fill_account_info(title, name, password, dob_day, dob_month, dob_year)
    time.sleep(2)
    test_placeorder.select_newsletter_and_offers()
    time.sleep(2)

    test_placeorder.fill_address(first_name, last_name, company, address1, address2, country, state, city, zipcode,
                               mobile_number)
    time.sleep(2)

    test_placeorder.create_account()
    time.sleep(2)

    test_placeorder.verify_account_creation()
    time.sleep(2)

    test_placeorder.continue_button()
    time.sleep(2)
    test_placeorder.cart_b()
    time.sleep(2)
    test_placeorder.checkout_button()
    time.sleep(1)
    test_placeorder.enter_message("Hi from Nisha")
    time.sleep(1)
    test_placeorder.click_place_order()
    time.sleep(1)
    test_placeorder.payment_details(nameoncard,number,cvc, expiry, year)
    time.sleep(1)
    test_placeorder.confirm_button()
    time.sleep(1)
    test_placeorder.verify_success_message()
    time.sleep(1)
    # test_placeorder.delete_account()
    # time.sleep(1)
    # test_placeorder.verify_account_deleted()
    # time.sleep(1)
    test_placeorder.continue_b()
    time.sleep(1)


