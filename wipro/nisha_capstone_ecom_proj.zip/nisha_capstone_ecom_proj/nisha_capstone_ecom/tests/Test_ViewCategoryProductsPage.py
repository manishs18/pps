import pytest
import time
from nisha_capstone_ecom.pages.ViewCategoryProductsPage import ViewCategoryProducts
from selenium import webdriver

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get("http://automationexercise.com")
    yield driver
    driver.close()

def test_product(driver):
    test_viewcat = ViewCategoryProducts(driver)
    test_viewcat.verify_homepage_title()
    time.sleep(1)
    test_viewcat.click_products()
    time.sleep(1)
    test_viewcat.click_women_cat()
    time.sleep(1)
    test_viewcat.click_women_subcat()
    time.sleep(1)
    test_viewcat.verify_women_subcat()
    time.sleep(1)
    test_viewcat.click_men_category()
    time.sleep(1)
    test_viewcat.click_men_subcategory()
    time.sleep(1)
    test_viewcat.verify_men_subcategory()
    time.sleep(1)