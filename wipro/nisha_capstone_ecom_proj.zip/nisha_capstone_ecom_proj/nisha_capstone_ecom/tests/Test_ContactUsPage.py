import time
import pytest
from nisha_capstone_ecom.pages.ContactUsPage import ContactUsPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_contact_us_form(driver):
    contact_page = ContactUsPage(driver)

    contact_page.verify_homepage_title()
    time.sleep(1)

    contact_page.click_contactus()
    time.sleep(1)

    contact_page.verify_contactus_page()
    time.sleep(1)

    contact_page.fill_contact_form(name="nisha25", email="nisha25@gmail.com", subject="Testing", message="Hello From Nisha")
    time.sleep(1)

    contact_page.upload_file(r"C:\Users\mkuma\OneDrive\Desktop\nisha_capstone_ecom_proj\nisha_capstone_ecom\tests\nisharootpath.png")
    time.sleep(1)

    contact_page.submit_form()
    time.sleep(1)

    contact_page.accept_alert()
    time.sleep(1)

    contact_page.verify_success_message()
    time.sleep(1)

    contact_page.click_home_button()
    time.sleep(1)
    contact_page.verify_homepage_title()
    time.sleep(1)


