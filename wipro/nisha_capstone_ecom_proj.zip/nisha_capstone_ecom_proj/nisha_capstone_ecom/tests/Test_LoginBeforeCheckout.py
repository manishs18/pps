import time
import pytest
from nisha_capstone_ecom.pages.LoginBeforeCheckout import LoginBeforeCheckout
from selenium import webdriver

@pytest.fixture()
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_login_user(driver):
    email = "nisha255@gmail.com"
    password = "nisha@255"
    username = "nisha255"
    nameoncard = "Master Nisha Deshmukh"
    number = "34731234"
    cvc = "255"
    expiry = "09"
    year = "28"

    login_page = LoginBeforeCheckout(driver)
    time.sleep(2)

    login_page.verify_homepage_title()
    time.sleep(2)

    login_page.click(*login_page.LOGIN_TO_ACCOUNT)
    time.sleep(2)

    login_page.verify_login_page()
    time.sleep(1)

    login_page.enter_credentials(email, password)
    login_page.click_login()
    time.sleep(1)

    login_page.verify_user_logged_in(username)
    time.sleep(1)
    login_page.add_to_cart()
    time.sleep(1)
    login_page.cart_b()
    time.sleep(2)
    login_page.checkout_button()
    time.sleep(1)
    login_page.enter_message("Hi from Nisha")
    time.sleep(1)
    login_page.click_place_order()
    time.sleep(1)
    login_page.payment_details(nameoncard,number,cvc, expiry, year)
    time.sleep(1)
    login_page.confirm_button()
    time.sleep(1)
    login_page.verify_success_message()
    time.sleep(1)