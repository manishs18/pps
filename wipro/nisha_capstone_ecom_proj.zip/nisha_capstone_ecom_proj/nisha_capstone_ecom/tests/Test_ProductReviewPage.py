import time
import pytest
from nisha_capstone_ecom.pages.ProductReviewPage import ProductReviewPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_place_order(driver):
    name = "nisha255"
    email = "nisha255@gmail.com"
    review = "Review is good!"

    test_productreview = ProductReviewPage(driver)
    time.sleep(2)

    test_productreview.verify_homepage_title()
    time.sleep(1)
    test_productreview.click_products()
    time.sleep(1)
    test_productreview.verify_products_page()
    time.sleep(1)
    test_productreview.click_view_products()
    time.sleep(1)
    test_productreview.verify_review_section()
    time.sleep(1)
    test_productreview.review_section(name, email, review)
    time.sleep(1)
    test_productreview.submit_button()
    print("Thank you for review! Message Visible")