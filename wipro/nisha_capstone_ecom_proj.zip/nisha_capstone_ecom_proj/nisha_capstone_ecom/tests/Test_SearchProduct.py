import time
import pytest
from nisha_capstone_ecom.pages.ProductPage import ProductPage
from nisha_capstone_ecom.pages.TescasePage import TestcasePage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()

def test_search_products(driver):
    test_searchproduct = ProductPage(driver)
    test_searchproduct.verify_homepage_title()
    time.sleep(1)
    test_searchproduct.click_products()
    time.sleep(2)
    test_searchproduct.verify_products_page()
    time.sleep(2)
    test_searchproduct.click_search_products("Polo")
    time.sleep(2)
    test_searchproduct.click_search_button()
    time.sleep(1)
    test_searchproduct.verify_searched_products()
    time.sleep(2)
    print("All the products related to search are visible")
