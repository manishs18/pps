import time

import pytest
from nisha_capstone_ecom.pages.RemoveProuctsPage import RemoveProductsPage
from selenium import webdriver

@pytest.fixture
def driver():
    option = webdriver.ChromeOptions()
    driver = webdriver.Chrome(options=option)
    driver.maximize_window()
    driver.get('http://automationexercise.com')
    yield driver
    driver.close()



def test_remove_products(driver):
    test_removeproducts = RemoveProductsPage(driver)
    test_removeproducts.verify_homepage_title()
    time.sleep(1)

    test_removeproducts.click_view_and_add_product()
    time.sleep(1)
    test_removeproducts.cart_button()
    time.sleep(1)
    test_removeproducts.verify_cart()
    time.sleep(1)
    test_removeproducts.click_x()
    time.sleep(1)
    test_removeproducts.verify_product_removed()
    time.sleep(1)