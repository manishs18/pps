import pytest
import time
from Pages.Locators import Locators


@pytest.mark.usefixtures("driver")
def test_testcases_page(driver):
    locator_page = Locators(driver)
    time.sleep(3)

    locator_page.click_testcases_btn()
    time.sleep(2)