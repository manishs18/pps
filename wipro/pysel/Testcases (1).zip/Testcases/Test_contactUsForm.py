import pytest
import time
from Pages.ContactPage import Contact


@pytest.mark.usefixtures("driver")
def test_valid_login(driver):
    contact_page = Contact(driver)
    time.sleep(2)

    contact_page.click_contact_us()
    time.sleep(2)

    contact_page.verify_get_in_touch()
    time.sleep(2)

    contact_page.contact_us_form("Jhon","jhon123@gmail.com", "feedback",
                                 "Nice product.", "C:/Users/Windows 11/Downloads/flowers.png")
    time.sleep(2)

    contact_page.alert_popup()
    time.sleep(2)

