import time
import pytest
from selenium.webdriver.common.by import By
from Pages.SubscriptionPage import Subscription

@pytest.mark.usefixtures("driver")
def test_verify_subscription(driver):
    subscription_page = Subscription(driver)
    time.sleep(2)

    SUBSCRIPTION = driver.find_element(By.XPATH, "//h2[normalize-space()='Subscription']")
    driver.execute_script("arguments[0].scrollIntoView();", SUBSCRIPTION)
    time.sleep(2)

    subscription_page.move_to_subscription("jhon123@gmail.com")
    time.sleep(2)