import pytest
import time
import random
import string
from selenium import webdriver
from Pages.HomePage import HomePage
from Pages.RegisterPage import RegisterPage
from Pages.Locators import Locators


@pytest.fixture
def driver():
    option = webdriver.EdgeOptions()
    driver = webdriver.Edge(options=option)
    driver.maximize_window()
    driver.get("https://automationexercise.com/")

    yield driver

    driver.quit()


random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
dynamic_username = f"{random_suffix}"
dynamic_email = f"{random_suffix}@example.com"


def test_register_user(driver):
    register_page = RegisterPage(driver)
    time.sleep(2)

    locator = Locators(driver)
    time.sleep(2)

    register_page.click_signin_btn()
    time.sleep(2)

    register_page.verify_home_page_visible()

    register_page.enter_signup(dynamic_username, dynamic_email)
    time.sleep(2)

    # Details of user
    register_page.enter_details("jhon@27", "Jhon", "Mark", "Canada",
                                "Canada", "Canada", "Canada", "123456", "123695487")
    time.sleep(2)

    register_page.click_continue()
    time.sleep(2)

    locator.click_logout()
    time.sleep(2)
