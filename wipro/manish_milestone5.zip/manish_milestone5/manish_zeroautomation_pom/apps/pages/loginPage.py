import time
from selenium.webdriver.common.by import By
from manish_zeroautomation_pom.apps.pages.basePage import BasePage


class LoginPage(BasePage):
    Click_Sign_In = (By.XPATH, "//button[@id='signin_button']")
    Username = (By.XPATH, "//input[@id='user_login']")
    Password = (By.XPATH, "//input[@id='user_password']")
    Login_Button = (By.XPATH, "//input[@name='submit']")
    More_Services = (By.XPATH, "//a[@id='online-banking']")
    Account_Summary = (By.XPATH, "//span[@id='account_summary_link']")
    click_Account_Summary = (By.XPATH, "//span[@id='account_summary_link']")
    Check_save = (By.XPATH, "/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]")
    Check_credit = (By.XPATH,"/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/table[1]/tbody[1]/tr[2]/td[1]")
    Check_check = (By.XPATH,"/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/table[1]/tbody[1]/tr[1]/td[1]")
    check_Balance = (By.XPATH,"//tbody//tr[1]//td[3]")
    Transfer_fund = (By.XPATH,"//span[@id='transfer_funds_link']")
    From_dropdown = (By.XPATH,"//select[@name='fromAccountId']")
    To_dropdown = (By.XPATH,"//select[@name='toAccountId']")
    Enter_amount = (By.XPATH,"//input[@id='tf_amount']")
    Descrip = (By.XPATH,"//input[@id='tf_description']")
    Click_Continue = (By.XPATH,"//button[@id='btn_submit']")
    CLick_submit =(By.XPATH,"//button[@id='btn_submit']")
    Status = (By.XPATH,"//div[@class='alert alert-success']")
    PayBill_Button = (By.XPATH,"//span[@id='pay_bills_link']")
    Payee = (By.XPATH,"//select[@id='sp_payee']")
    Account = (By.XPATH,"//select[@id='sp_account']")
    PayAmount = (By.XPATH,"//input[@id='sp_amount']")
    Date = (By.XPATH,"//input[@id='sp_date']")
    PAyDesc = (By.XPATH,"//input[@id='sp_description']")
    Pay_Button = (By.XPATH,"//input[@id='pay_saved_payees']")
    PayStatus = (By.XPATH,"//div[@id='alert_content']")
    Click_Activity = (By.XPATH,"//span[@id='account_activity_link']")
    Search_Account = (By.XPATH,"//select[@id='aa_accountId']")
    Click_Find_transaction = (By.XPATH,"//a[normalize-space()='Find Transactions']")
    Search_transaction = (By.XPATH,"//input[@id='aa_description']")
    Find_Button = (By.XPATH,"//button[@type='submit']")
    Check_Search = (By.XPATH,"/html[1]/body[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/table[1]/tbody[1]/tr[2]/td[2]")
    def click_sign_in(self):
        self.click(*self.Click_Sign_In)
    def login(self,username,password):
        self.send_keys(*self.Username,username)
        self.send_keys(*self.Password, password)
        self.click(*self.Login_Button)
        self.click(*self.More_Services)
        return self.get_text(*self.Account_Summary)

    def click_account_summary(self):
        self.click(*self.click_Account_Summary)

    def check_content(self):
        save = self.get_text(*self.Check_save)
        credit = self.get_text(*self.Check_credit)
        check = self.get_text(*self.Check_check)
        return save,credit,check

    def Check_balance(self):
        balance = self.get_text(*self.check_Balance)
        return balance

    def click_transfer_fund(self):
        self.click(*self.Transfer_fund)

    def enter_from(self):
        dropdown = self.get_dropdown(*self.From_dropdown)
        dropdown.select_by_index(2)

    def enter_to(self,amount,desc):
        dropdown = self.get_dropdown(*self.To_dropdown)
        dropdown.select_by_index(3)
        self.send_keys(*self.Enter_amount,amount)
        self.send_keys(*self.Descrip,desc)
        self.click(*self.Click_Continue)
        self.click(*self.CLick_submit)
        return self.get_text(*self.Status)

    def click_pay_bill(self):
        self.click(*self.PayBill_Button)

    def Pay_Bill(self):
        pay = self.get_dropdown(*self.Payee)
        pay.select_by_index(2)
        account = self.get_dropdown(*self.Account)
        account.select_by_index(2)
        self.send_keys(*self.PayAmount,"110")
        self.send_keys(*self.Date,"2025-01-22")
        self.send_keys(*self.PAyDesc,"Fine")
        self.click(*self.Pay_Button)
        time.sleep(2)
        return self.get_text(*self.PayStatus)


    def Check_account_Acitivity(self):
        self.click(*self.Click_Activity)
        self.get_dropdown(*self.Search_Account).select_by_index(3)
        self.click(*self.Click_Find_transaction)
        self.send_keys(*self.Search_transaction,"RENT")
        self.click(*self.Find_Button)
        return self.get_text(*self.Check_Search)


