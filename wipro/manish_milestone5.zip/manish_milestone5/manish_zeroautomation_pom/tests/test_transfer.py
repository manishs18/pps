import time
import pytest
from selenium import webdriver
from manish_zeroautomation_pom.apps.pages.loginPage import LoginPage


@pytest.fixture
def driver():
    option = webdriver.EdgeOptions()
    driver = webdriver.Edge(options=option)
    driver.maximize_window()
    driver.get('http://zero.webappsecurity.com/')
    yield driver
    driver.quit()

def test_Transfer(driver):
    lp = LoginPage(driver)
    lp.click_sign_in()
    time.sleep(4)
    lp.login("username","password")
    lp.click_transfer_fund()
    time.sleep(4)
    lp.enter_from()
    time.sleep(2)
    status =lp.enter_to(100,"Done")
    time.sleep(2)
    print(status)

