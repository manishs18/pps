import time
import pytest
from selenium import webdriver
from manish_zeroautomation_pom.apps.pages.loginPage import LoginPage


@pytest.fixture
def driver():
    option = webdriver.EdgeOptions()
    driver = webdriver.Edge(options=option)
    driver.maximize_window()
    driver.get('http://zero.webappsecurity.com/')
    yield driver
    driver.quit()

def test_login_Summary(driver):
    lp = LoginPage(driver)
    lp.click_sign_in()
    time.sleep(4)
    text=lp.login("username","password")
    assert text == "Account Summary"
    time.sleep(4)
    lp.click_account_summary()
    save,credit,check = lp.check_content()
    if save=="" and credit=="" and check=="":
        print("No data found")
    else:
        print("Data found")

    text = lp.Check_balance()
    print(text)

