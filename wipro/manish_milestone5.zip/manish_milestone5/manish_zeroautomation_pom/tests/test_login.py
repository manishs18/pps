import time
import pytest
from selenium import webdriver
from manish_zeroautomation_pom.apps.pages.loginPage import LoginPage

@pytest.fixture
def driver():
    option = webdriver.EdgeOptions()
    driver = webdriver.Edge(options=option)
    driver.maximize_window()
    driver.get('http://zero.webappsecurity.com/')
    yield driver
    driver.quit()

def test_login(driver):
    lp = LoginPage(driver)
    lp.click_sign_in()
    time.sleep(4)
    text=lp.login("username","password")
    assert text == "Account Summary"
    time.sleep(4)

