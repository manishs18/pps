import time
import pytest
from selenium import webdriver
from manish_zeroautomation_pom.apps.pages.loginPage import LoginPage


@pytest.fixture
def driver():
    option = webdriver.EdgeOptions()
    driver = webdriver.Edge(options=option)
    driver.maximize_window()
    driver.get('http://zero.webappsecurity.com/')
    yield driver
    driver.quit()

def test_Search(driver):
    lp = LoginPage(driver)
    lp.click_sign_in()
    time.sleep(4)

    lp.login("username", "password")
    time.sleep(4)

    text = lp.Check_account_Acitivity()
    assert text == "RENT"

